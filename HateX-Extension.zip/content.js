/**
 * HateX content script
 * - Observes chat DOM on YouTube Live & Twitch
 * - Applies simple rules to hide/blur abusive & hateful messages
 * - All processing is on-device; no data leaves the browser
 */

const DEFAULT_SETTINGS = {
  enabled: true,
  action: "hide", // "hide" | "blur"
  strictness: 2,  // 1=light, 2=balanced, 3=strict
  platforms: { youtube: true, twitch: true },
  // Keep the default list generic; users can expand in Options.
  // Do not include explicit slurs in this starter.
  keywords: [
    "trash", "stupid", "idiot", "dumb", "loser"
  ],
  // phrases representing threats/harassment patterns (non-explicit)
  patterns: [
    "(?:go\\s+back\\s+to)",
    "(?:you\\s+don'?t\\s+belong)",
    "(?:not\\s+welcome\\s+here)",
    "(?:get\\s+out\\s+of\\s+here)",
    "(?:hate\\s+you)"
  ]
};

let state = {
  settings: null,
  blockedCount: 0,
};

function loadSettings() {
  return new Promise((resolve) => {
    chrome.storage.sync.get({ settings: DEFAULT_SETTINGS }, (res) => {
      // Merge with defaults in case new fields were added
      const merged = { ...DEFAULT_SETTINGS, ...(res.settings||{}) };
      merged.platforms = { ...DEFAULT_SETTINGS.platforms, ...(merged.platforms||{}) };
      if (!Array.isArray(merged.keywords)) merged.keywords = DEFAULT_SETTINGS.keywords.slice();
      if (!Array.isArray(merged.patterns)) merged.patterns = DEFAULT_SETTINGS.patterns.slice();
      state.settings = merged;
      resolve(merged);
    });
  });
}

function saveSettings(newSettings) {
  return new Promise((resolve) => {
    chrome.storage.sync.set({ settings: newSettings }, () => resolve());
  });
}

function isYouTube() {
  return location.hostname.includes("youtube.com");
}
function isTwitch() {
  return location.hostname.includes("twitch.tv");
}

function getChatContainers() {
  if (isYouTube()) {
    // Live chat in watch/live pages
    return [
      ...document.querySelectorAll(
        "ytd-live-chat-frame #chat, ytd-live-chat-app #contents, yt-live-chat-renderer #contents, #chat #items"
      )
    ];
  }
  if (isTwitch()) {
    return [
      ...document.querySelectorAll(
        ".chat-scrollable-area__message-container, .chat-room__content, .chat-list--default, .chat-list__lines"
      )
    ];
  }
  return [];
}

function getMessageNodes(container) {
  if (isYouTube()) {
    // Messages on YT live chat
    return [
      ...container.querySelectorAll(
        "yt-live-chat-text-message-renderer, yt-live-chat-membership-item-renderer, yt-live-chat-paid-message-renderer"
      )
    ];
  }
  if (isTwitch()) {
    // Twitch message rows
    return [
      ...container.querySelectorAll("[data-a-target='chat-line-message'], .chat-line__message")
    ];
  }
  // Fallback
  return [...container.querySelectorAll("*")].filter(n => n.textContent && n.childElementCount === 0);
}

function buildRegex(settings) {
  // keywords -> word boundaries; strictness adjusts sensitivity
  const kw = (settings.keywords || []).map(k => k.trim()).filter(Boolean);
  const patterns = (settings.patterns || []).map(p => p.trim()).filter(Boolean);
  const kwPart = kw.length ? `\\b(?:${kw.map(escapeRegex).join("|")})\\b` : null;
  const extra = patterns.length ? `(?:${patterns.join("|")})` : null;

  let source = "";
  if (kwPart && extra) source = `${kwPart}|${extra}`;
  else if (kwPart) source = kwPart;
  else if (extra) source = extra;
  else source = "(?!x)x"; // match nothing

  // Strictness modifies word boundary behavior and case
  const flags = "i";
  return new RegExp(source, flags);
}

function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function scoreText(text, regex) {
  // Simple heuristic score: number of matches + emphasis
  let score = 0;
  const matches = text.match(regex);
  if (matches) score += matches.length * 2;

  // UPPERCASE shouting
  if (text.length >= 6) {
    const letters = text.replace(/[^a-z]/gi,"");
    if (letters && letters.length >= 6) {
      const ratioCaps = (letters.replace(/[a-z]/g,"").length) / letters.length;
      if (ratioCaps > 0.7) score += 1;
    }
  }

  // Repeated punctuation !!! or ???
  if (/[!?]{3,}/.test(text)) score += 1;

  return score;
}

function shouldBlock(text, settings, regex) {
  const s = (text || "").trim();
  if (!s) return false;

  const score = scoreText(s, regex);
  if (settings.strictness === 1) return score >= 2;
  if (settings.strictness === 2) return score >= 1;
  return score >= 0.5; // strict mode, any hit
}

function actOnNode(node, settings) {
  const action = settings.action || "hide";
  if (action === "hide") {
    if (!node.__hatexHidden) {
      const ph = document.createElement("div");
      ph.className = "hatex-placeholder";
      ph.textContent = "Message hidden by HateX";
      node.style.display = "none";
      node.insertAdjacentElement("afterend", ph);
      node.__hatexHidden = true;
      state.blockedCount++;
    }
  } else {
    node.classList.add("hatex-blur");
    state.blockedCount++;
  }
}

function analyzeNode(node, settings, regex) {
  try {
    let text = "";
    if (isYouTube()) {
      const msgSpan = node.querySelector("#message") || node;
      text = msgSpan.textContent || "";
    } else if (isTwitch()) {
      const msgSpan = node.querySelector("[data-a-target='chat-message-text']") || node;
      text = msgSpan.textContent || "";
    } else {
      text = node.textContent || "";
    }
    if (shouldBlock(text, settings, regex)) {
      actOnNode(node, settings);
    }
  } catch (e) {
    // ignore
  }
}

let observer = null;

async function init() {
  const settings = await loadSettings();
  if (!settings.enabled) return;

  if ((isYouTube() && !settings.platforms.youtube) || (isTwitch() && !settings.platforms.twitch)) {
    return;
  }

  const regex = buildRegex(settings);
  const containers = getChatContainers();
  containers.forEach(container => {
    // scan existing
    getMessageNodes(container).forEach(n => analyzeNode(n, settings, regex));
    // observe new
    const mo = new MutationObserver(muts => {
      for (const m of muts) {
        m.addedNodes && m.addedNodes.forEach(n => {
          if (n.nodeType === 1) {
            if (n.matches && (n.matches("yt-live-chat-text-message-renderer, [data-a-target='chat-line-message'], .chat-line__message"))) {
              analyzeNode(n, settings, regex);
            } else {
              getMessageNodes(n).forEach(child => analyzeNode(child, settings, regex));
            }
          }
        });
      }
    });
    mo.observe(container, { childList: true, subtree: true });
  });

  // Respond to live settings changes
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "sync" && changes.settings) {
      // Reload on settings change
      location.reload();
    }
  });
}

init();