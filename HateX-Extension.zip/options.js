const DEFAULT_SETTINGS = {
  enabled: true,
  action: "hide",
  strictness: 2,
  platforms: { youtube: true, twitch: true },
  keywords: ["trash","stupid","idiot","dumb","loser"],
  patterns: ["(?:go\\s+back\\s+to)","(?:you\\s+don'?t\\s+belong)","(?:not\\s+welcome\\s+here)","(?:get\\s+out\\s+of\\s+here)","(?:hate\\s+you)"]
};

function load() {
  chrome.storage.sync.get({ settings: DEFAULT_SETTINGS }, ({settings}) => {
    settings = { ...DEFAULT_SETTINGS, ...(settings||{}) };
    document.getElementById('enabled').checked = !!settings.enabled;
    document.getElementById('action').value = settings.action || "hide";
    document.getElementById('strictness').value = settings.strictness || 2;
    document.getElementById('strictnessLabel').textContent = ["Light","Balanced","Strict"][(settings.strictness||2)-1];
    document.getElementById('yt').checked = settings.platforms?.youtube ?? true;
    document.getElementById('tw').checked = settings.platforms?.twitch ?? true;
    document.getElementById('keywords').value = (settings.keywords||[]).join(", ");
    document.getElementById('patterns').value = (settings.patterns||[]).join("\n");
  });
}
function save() {
  const settings = {
    enabled: document.getElementById('enabled').checked,
    action: document.getElementById('action').value,
    strictness: parseInt(document.getElementById('strictness').value, 10),
    platforms: {
      youtube: document.getElementById('yt').checked,
      twitch: document.getElementById('tw').checked
    },
    keywords: document.getElementById('keywords').value.split(",").map(s => s.trim()).filter(Boolean),
    patterns: document.getElementById('patterns').value.split("\n").map(s => s.trim()).filter(Boolean),
  };
  chrome.storage.sync.set({ settings }, () => {
    const s = document.getElementById('status');
    s.textContent = "Saved ✓";
    setTimeout(() => s.textContent = "", 1500);
  });
}

document.getElementById('save').addEventListener('click', save);
document.getElementById('strictness').addEventListener('input', e => {
  document.getElementById('strictnessLabel').textContent = ["Light","Balanced","Strict"][parseInt(e.target.value,10)-1];
});
document.addEventListener('DOMContentLoaded', load);