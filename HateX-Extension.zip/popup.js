function load() {
  chrome.storage.sync.get({ settings: {} }, ({settings}) => {
    document.getElementById('enabled').checked = settings.enabled ?? true;
    document.getElementById('action').value = settings.action || "hide";
    document.getElementById('strictness').value = String(settings.strictness || 2);
    document.getElementById('status').textContent = "Ready";
  });
}
function save() {
  chrome.storage.sync.get({ settings: {} }, ({settings}) => {
    settings.enabled = document.getElementById('enabled').checked;
    settings.action = document.getElementById('action').value;
    settings.strictness = parseInt(document.getElementById('strictness').value, 10);
    chrome.storage.sync.set({ settings }, () => {
      const s = document.getElementById('status');
      s.textContent = "Saved ✓";
      setTimeout(() => window.close(), 500);
    });
  });
}
document.getElementById('save').addEventListener('click', save);
document.addEventListener('DOMContentLoaded', load);