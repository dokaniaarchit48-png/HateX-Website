# HateX — Live Chat Hate & Abuse Blocker (Browser Extension)

This extension hides or blurs abusive and hateful messages in live stream chats (YouTube, Twitch). It runs entirely in your browser and never sends chat data anywhere.

## Install (Chrome, Edge)
1. Download the ZIP and extract it.
2. Open `chrome://extensions` and toggle **Developer mode**.
3. Click **Load unpacked** and select the extracted folder.
4. Pin **HateX** from the toolbar.

## Install (Firefox Nightly/Developer)
Firefox MV3 is evolving. You can try loading as a temporary add-on via `about:debugging` → **This Firefox** → **Load Temporary Add-on…** and pick `manifest.json`.

## Use
- Click the toolbar icon to **enable/disable** or adjust **strictness** quickly.
- Open **Options** to add **custom keywords** and **regex patterns**.
- Choose **Hide** or **Blur** action.

## Notes
- The default list is intentionally generic. Add your community's needs to `Options → Blocked Keywords`.
- No automated system is perfect — periodically review your settings.
- You can extend the matchers in `content.js` to support more platforms by adding host patterns and selectors.

## Development tips
- Open DevTools on the chat page, switch to **Elements**, and inspect the chat message markup. Update selectors in `content.js` if the platform UI changes.
- If you update settings while a chat page is open, the content script will auto‑reload on the next change.